// Copyright 2011 Google Inc. All Rights Reserved.

package com.google.jstestdriver.config;

/**
 * @author corysmith@google.com (Cory Smith)
 *
 */
public enum ExecutionType {
  INTERACTIVE, STANDALONE
}
