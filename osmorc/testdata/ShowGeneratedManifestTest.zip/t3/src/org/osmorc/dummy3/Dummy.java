package org.osmorc.dummy3;

/**
 * Yet another dummy class.
 */
public class Dummy {
}
