package org.osmorc.dummy2;

/**
 * Another dummy class.
 */
public class Dummy2 {
}
