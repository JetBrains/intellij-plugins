package org.osmorc.dummy;


/**
 * Dummy class.
 */
public class Dummy {
}
