package org.osgi.framework;

public interface BundleContext
{
}
