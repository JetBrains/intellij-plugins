package org.osgi.framework;

public interface BundleActivator
{
    start(BundleContext context) throws Exception;
    stop(BundleContext context) throws Exception;
}
