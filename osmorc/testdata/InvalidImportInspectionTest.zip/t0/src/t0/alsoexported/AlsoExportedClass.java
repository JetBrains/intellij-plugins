package t0.alsoexported;

public class AlsoExportedClass
{
  public void doSomething()
  {

  }
}