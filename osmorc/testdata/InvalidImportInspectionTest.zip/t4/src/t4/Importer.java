package t4;

import t0.ExportedClass;
import t0.alsoexported.AlsoExportedClass;
import t0.internal.NotExportedClass;

public class Importer
{
  public void doSomething()
  {
    ExportedClass e = new ExportedClass();
    AlsoExportedClass a = new AlsoExportedClass();
    NotExportedClass n = new NotExportedClass();

    e.doSomething();
    a.doSomething();
    n.doSomething();
  }
}