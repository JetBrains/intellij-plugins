package t1;

import t0.ExportedClass;

public class Importer
{
  public void doSomething()
  {
    ExportedClass e = new ExportedClass();

    e.doSomething();
  }
}