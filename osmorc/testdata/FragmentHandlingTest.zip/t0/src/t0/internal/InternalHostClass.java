package t0.internal;

public class InternalHostClass
{
  public void doSomething()
  {

  }
}