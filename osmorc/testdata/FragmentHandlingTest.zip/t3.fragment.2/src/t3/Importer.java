package t3;

import t2.T2;

public class Importer
{
  public void doSomething()
  {
  }
}