package t2;

public class T2
{
  public void doSomething()
  {
  }
}