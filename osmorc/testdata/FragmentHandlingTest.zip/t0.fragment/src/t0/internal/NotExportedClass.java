package t0.internal;

public class NotExportedClass
{
  public void doSomething()
  {
	  InternalHostClass hostObject = new InternalHostClass();
	  hostObject.doSomething();
  }
}