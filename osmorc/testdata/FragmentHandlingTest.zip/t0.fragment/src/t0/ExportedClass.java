package t0;

public class ExportedClass
{
  public void doSomething()
  {

  }
}