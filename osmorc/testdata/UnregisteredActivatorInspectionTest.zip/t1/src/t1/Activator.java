package t1;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator  implements BundleActivator 
{
    public void start(BundleContext context) throws Exception
    {
    }

    public void stop(BundleContext context) throws Exception
    {
    }
}
