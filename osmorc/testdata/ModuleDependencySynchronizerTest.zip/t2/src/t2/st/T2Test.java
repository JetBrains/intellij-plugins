package t2.st

public void class T2Test
{

}