package org.jetbrains.flash.abcBuilder;

abstract class BaseTypeBuilder extends BaseBuilder {
  BaseTypeBuilder(String name) {
    super(name);
  }

  protected void createMethods(@SuppressWarnings("UnusedParameters") int initScopeDepth) {
  }
}
