package org.jetbrains.flash.abcBuilder;

public class AbcFile {
}
