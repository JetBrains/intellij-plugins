package org.jetbrains.flash.abcBuilder;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ClassBuilder extends BaseTypeBuilder {
  private static final int HIERARCHY_DEPTH_OFFSET = 3;
  
  private final String superQualifiedName;
  private final PackageBuilder packageBuilder;
  private final List<PropertyBuilder> propertyBuilders = new ArrayList<PropertyBuilder>();

  public ClassBuilder(PackageBuilder packageBuilder, String name, @Nullable String superQualifiedName) {
    super(name);
    this.packageBuilder = packageBuilder;
    this.superQualifiedName = superQualifiedName == null ? "Object" : superQualifiedName;
  }

  public PropertyBuilder defineProperty(String name, String type) {
    final PropertyBuilder propertyBuilder = new PropertyBuilder(name, type);
    propertyBuilders.add(propertyBuilder);
    return propertyBuilder;
  }

  void build(AbcBuilder abcBuilder, ClassInfoProvider classInfoProvider) {
    final int hierarchyDepth = HIERARCHY_DEPTH_OFFSET + classInfoProvider.getSuperClassesCount(superQualifiedName);
    createMethods(hierarchyDepth + 1);
    createSlots(abcBuilder);
  }

  private void createSlots(AbcBuilder abcBuilder) {
    for (PropertyBuilder propertyBuilder : propertyBuilders) {
      propertyBuilder.build(abcBuilder);
    }
  }
}
