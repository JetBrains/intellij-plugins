package org.jetbrains.flash.abcBuilder;

final class SlotOrConstantTrait extends TraitInfo {
}
