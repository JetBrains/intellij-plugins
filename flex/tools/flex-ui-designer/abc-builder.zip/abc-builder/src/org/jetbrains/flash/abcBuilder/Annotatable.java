package org.jetbrains.flash.abcBuilder;

abstract class Annotatable {
}
