package org.jetbrains.flash.abcBuilder;

public class Main {
  public static void main(String[] args) {
    AbcBuilder abcBuilder = new AbcBuilder();
    PackageBuilder packageBuilder = abcBuilder.definePackage("p");
    ClassBuilder classBuilder = packageBuilder.defineClass("RuntimeClass");
    classBuilder.defineProperty("name", "String");
    abcBuilder.build();
  }
}