package org.jetbrains.flash.abcBuilder;

class EmitMember extends BaseBuilder {
  EmitMember(String name, MemberVisibility visibility) {
    super(name, visibility);
  }
}
