package org.jetbrains.flash.abcBuilder;

public class PropertyBuilder extends EmitMember {
  private final String type;

  PropertyBuilder(String name, String type) {
    super(name, MemberVisibility.PUBLIC);
    this.type = type;
  }

  TraitInfo build(AbcBuilder abcBuilder) {
    return buildTrait();
  }

  protected TraitInfo buildTrait() {
    SlotOrConstantTrait trait = new SlotOrConstantTrait();
  			trait.addMetadataList(buildMetadata());
  			trait.isFinal = isFinal;
  			trait.isOverride = isOverride;
  			trait.traitKind = (isConstant) ? TraitKind.CONST : TraitKind.SLOT;
  			trait.isStatic = isStatic;
  			trait.typeMultiname = MultinameUtil.toQualifiedName(_type);
  			var ns:LNamespace = createTraitNamespace();
  			trait.traitMultiname = new QualifiedName(name, ns);
  			if (_initialValue === undefined) {
  				trait.vindex = 0;
  			} else {
  				trait.vkind = ConstantKind.determineKindFromInstance(_initialValue);
  				trait.defaultValue = _initialValue;
  			}
  			return trait;
  		}
}
