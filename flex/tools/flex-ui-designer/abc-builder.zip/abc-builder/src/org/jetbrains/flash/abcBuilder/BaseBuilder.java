package org.jetbrains.flash.abcBuilder;

abstract class BaseBuilder {
  protected final String name;
  private MemberVisibility visibility;

  BaseBuilder(String name) {
    this(name, MemberVisibility.PUBLIC);
  }

  BaseBuilder(String name, MemberVisibility visibility) {
    this.name = name;
    this.visibility = visibility;
  }
}
