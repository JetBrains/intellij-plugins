package org.jetbrains.flash.abcBuilder;

import gnu.trove.THashMap;

import java.util.Map;

public class AbcBuilder {
  private final Map<String, PackageBuilder> packageBuilders = new THashMap<String, PackageBuilder>();

  public AbcBuilder() {
  }

  public PackageBuilder definePackage(String name) {
    PackageBuilder packageBuilder = packageBuilders.get(name);
    if (packageBuilder == null) {
      packageBuilder = new PackageBuilder(name);
      packageBuilders.put(name, packageBuilder);
    }

    return packageBuilder;
  }

  public AbcFile build(ClassInfoProvider classInfoProvider) {
    AbcFile abcFile = new AbcFile();
    for (PackageBuilder packageBuilder : packageBuilders.values()) {
      packageBuilder.build(this, classInfoProvider);
    }
  }
}

enum MemberVisibility {
  PUBLIC
}
