package org.jetbrains.flash.abcBuilder;

public interface ClassInfoProvider {
  int getSuperClassesCount(String name);
}
