package org.jetbrains.flash.abcBuilder;

abstract class TraitInfo extends Annotatable {
}
