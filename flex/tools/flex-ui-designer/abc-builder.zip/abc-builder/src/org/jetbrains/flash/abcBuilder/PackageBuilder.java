package org.jetbrains.flash.abcBuilder;

import com.google.common.base.Strings;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;

public class PackageBuilder {
  // we need predictable iteration order
  private final Map<String, ClassBuilder> classBuilders = new LinkedHashMap<String, ClassBuilder>();

  private final String packageName;
  private final boolean isDefaultPackage;

  public PackageBuilder(@Nullable String packageName) {
    isDefaultPackage = Strings.isNullOrEmpty(packageName);
    this.packageName = Strings.nullToEmpty(packageName);
  }

  public ClassBuilder defineClass(String name) {
    return defineClass(name, null);
  }

  public ClassBuilder defineClass(String name, @Nullable String superQualifiedName) {
    ClassBuilder classBuilder = classBuilders.get(name);
    if (classBuilder == null) {
      classBuilder = new ClassBuilder(this, name, superQualifiedName);
      classBuilders.put(name, classBuilder);
    }

    return classBuilder;
  }

  void build(AbcBuilder abcBuilder, ClassInfoProvider classInfoProvider) {
    for (ClassBuilder classBuilder : classBuilders.values()) {
      classBuilder.build(abcBuilder, classInfoProvider);
    }
  }
}